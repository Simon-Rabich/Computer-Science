public class WinTester

{

    public static void main(String[] args)

    {

        int[] arr1 = {1, 1, 1, 5};

        Ex14.win(arr1);

        System.out.println();

        int[] arr2 = {1, 1, 5, 1};

        Ex14.win(arr2);

        System.out.println();

        int[] arr3 = {1, 5, 1, 1};

        Ex14.win(arr3);

        System.out.println();

        int[] arr4 = {5, 1, 1, 1};

        Ex14.win(arr4);

        System.out.println();

        int[] arr5 = {1, 3, 100, 2};

        Ex14.win(arr5);

        System.out.println();

        int[] arr6 = {1, 500, 100, 2};

        Ex14.win(arr6);

        System.out.println();

        int[] arr7 = {1, 8, 9, 1, 300, 20, 300, 500, 1000, 90};

        Ex14.win(arr7);

        System.out.println();

        int[] arr8 = {20, 20, 20, 20};

        Ex14.win(arr8);

        System.out.println();

        int[] arr9 = {30, 40, 50, 60};

        Ex14.win(arr9);

        System.out.println();

        int[] arr10 = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 9, 8, 7, 6, 5, 4, 3, 2};

        Ex14.win(arr10);

    }

}